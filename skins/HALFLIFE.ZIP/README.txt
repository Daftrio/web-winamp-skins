'..'``'..'[ README FILE FOR HALF LIFE AMP VERSION 2.0 ]'..'``'..'

Yo watz-up?

Creator Infomation:
Name           :   James Keen
AKA            :   The Sage
Email          :   protek_x@hotmail.com
ICQ            :   45265440, my nickname is [The_Sage]
URL            :   http://sagesoftware.cjb.net
MSN Messenger  :   Yes i have it, use the hotmail address to 
                   find me, i am [The_Sage]

Readme file Infomation:
This is the readme file for the skin "Half Life Amp version 2.0" 
i know for a fact that nobodys gonna read this file, i know i 
wouldent, so i can say what ever i like, like say err...."your 
all a bunch of losers" and i wont get into trouble cos nobody 
reads the readme file :-) nah sorry, just kidding now for the 
serious stuff

Skin Infomation:
Version : 1.2
Genral skin infomation:
This skin was made by me James Keen AKA The Sage
I spent about 48 non-stop back brakeing hours into doing the 
original skin and a hell of a lot of time updateing it aswell, 
so i dont want none of you guys/gals copying any part of my 
skin, stealing any part of my skin, sleeping with any part of 
my skin, or otherwise infringing on my copyrights ok?? 
cos if ya do, i could even be forsed to use pork power 
(get the police on ya for the more PC people out there) 

History:
V1.1    :  Skin is new
V1.2    :  Put some finishing touches on to the playlist editor
           and the minibrowser that should have been included in
           V1.1 (DOH!) and i made this readme file look better
           aswell, also the .zip is MUCH smaller in size,
V2.0    :  Equliser wheels rotate with the button, (looks REALLY cool
           download to see) same thing done with the volume and ballence 
           wheels, lots of bugs fixed, the numbers now look like LED ones 
           and not the winamp ones, clutter bar skinned, new logo,
           updated readme file,
           
Enjoy Half Life Amp
James Keen
"if you see your mom this weekend will you be sure to tell her....SATAN SATAN SATAN"